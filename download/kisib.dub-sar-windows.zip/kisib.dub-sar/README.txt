kisib.dub-sar v0.1 — Screen 1
Windows 11 Home / Pro; read-only certificate explorer

Open kisib.dub-sar.exe from the fully extracted download folder.
The source repository includes Start.cmd and the optional Build.cmd compiler command.
Neither launcher requests elevation, changes execution policy or downloads code.

Classic Explorer: tree left, list right, details below.
The tree shows Windows location > system store > physical store.
Every returned physical store has its own count, including zero.
A grey “not present” item is a Microsoft documentation reference, not an observed store.
Failed/incomplete enumeration stays unknown and reports the source error.

Columns: Subject CN, Issuer CN, C=, found in (physical stores), not-before,
not-after, SHA-1, SHA-256. Names use CN then O; full DNs stay in Details.
C= is the certificate's own declaration, not an owner or affiliation finding.
Find filters rows while keeping every native branch and count.
GROUPS AND BLOCKING
Under the store tree is Groups: Tags (👑, 🌿🧱, Google, eMudhra, your_group...),
Countries and Owners, built from data\countries_monarchy_bric.csv and
data\owners.csv. Edit those files and press F5. Each group has Enabled and
Blocked. Select a group, click Block group..., check the preview, click Block.
Blocked certificates go into Windows' Disallowed store (this user; whole PC
when kisib runs as administrator). Nothing is deleted. Undo last block puts
it back. Block > Block history shows every change.

KEEP GROUPS BLOCKED
Block > Update Microsoft root list downloads every root Windows trusts, including
ones not on this PC yet, so they can be blocked before they ever arrive.
In the Block group preview, leave "Keep this group blocked" ticked: kisib saves a
rule and, every 60 seconds, blocks anything new that lands in that group.
Block > Rules lists and removes rules. The status bar shows what rules caught.

MORE VIEWS
View > Standings: CA owners grouped by country with roots, intermediates,
expiring in 12 months, expired, blocked, weak and tags. Click a heading to sort.
Certificate > Show chain: the chain Windows builds, root on the left, with
hashes, where each one is found, blocked or not, and tags.
File > Open certificate file (Ctrl+O): .cer .crt .der .pem .p7b .sst shown
read-only, with whether each is on this PC and blocked. Never installs; .pfx
and .p12 are refused. "Open with" kisib works too (Build.cmd makes the exe).
Status bar: Clock ok | SUSPECT when the PC clock is earlier than the newest
certificate or nearly everything reads as expired.

View > Incident check matches every certificate on this PC against the published eMudhra
hashes and keys: HIT or MISS, where it was found, and whether Windows' Disallowed store
holds it. Read-only; MISS never means safe.
Click the bottom error count for the complete Store/Error list.

View > Optional features has exactly four switches, OFF every launch:
Journal, Archive public certificates, 60-second automatic scan, Syscall capture.
Default opening creates no history directory or automatic scan/capture.
Journal logs observations without saving public DER or inventories.
Archive is a separate opt-in requiring Journal. Existing records remain when disabled.
Syscall capture requires Archive; access failures do not trigger elevation.
Stop capture and finish the current scan before changing recording settings.
Original syscall events remain in the ETL; counts do not establish certificate use.

Microsoft terms, Learn URLs and documented/to test tags are in Help > Feature
sources and docs/feature-sources.csv. API documentation, custom display behavior,
hosted verification and user-PC acceptance are separate evidence.

ACCEPTANCE — USER PC, NOT CI [to test]
Leave Optional features off. Expand LOCAL_MACHINE > Root. Type FNMT into Find.
Take the whole-window screenshot on that PC. Children/counts must reflect Windows.
Absent documented siblings remain grey references. CI cannot satisfy this gate.

Only Screen 1 is current. Blocking, country/group integration, chain grids,
observed-app decisions and Explorer associations are parked. Do not build,
stub or scaffold them before the previous acceptance passes.
The supplied country CSV is saved unchanged for S3; Screen 1 does not read it.
Prior implementations and evidence remain in Git and historical documents.

Scope: docs/current-task-and-roadmap.txt and docs/screen1-scope.txt.
Registers: docs/function-catalog.csv and docs/feature-sources.csv.
Test.cmd is the read-only consumer-machine suite. Hosted CI separately runs
collector probes in disposable VMs, GUI regressions and the actual EXE.
Current evidence: docs/screen1-verification.txt. User-PC acceptance is pending.
This is an unsigned preview; no Microsoft Store submission is claimed.
